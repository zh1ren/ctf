#!/bin/sh
/home/oreo/oreo 2>&1
